//
//  File.swift
//  wwdc_submission
//
//  Created by mystic on 2022/04/17.
//

import SwiftUI
struct leverage_page : View{
    var body: some View{
        ZStack {
            Color.white
            VStack{
                leverage_slider()
                Spacer()
            }
        }
    }
}

struct leverage_slider: View {
    @State var width : CGFloat = 100
    @State var datalist : [CGFloat] = [0,0]
    @State var riskdepth : Double = 0
    @State var ablemoney : CGFloat = 1000
    @State var risk_leverage = ""
    
    var body: some View {
        VStack {
            Text("but some investor use leverage that is borrowing money.Although theoretically optimal leverage is known to be good, most individual investors who use leverage are at risk.\n")
                .font(.largeTitle)
                .padding()
            Text("leverage:\(Float(width/100))")
                .font(.largeTitle)
            ZStack(alignment:.leading){
                Rectangle()
                    .fill(Color.black.opacity(0.2))
                    .frame(width:730, height:6)
            
                Rectangle()
                    .fill(Color.black)
                    .frame(width:self.width,height: 6)
                HStack{
                    Circle()
                        .fill(Color.black)
                        .frame(width: 18, height: 18)
                        .offset(x:self.width)
                        .gesture(
                        
                            DragGesture()
                                .onChanged({ value in
                                    if(value.location.x > 100 && (value.location.x)/100 < 7.3){
                                        self.width = value.location.x
                                        self.datalist.append(self.width)
                                        self.riskdepth = (value.location.x - 100) / 1000
                                        self.ablemoney = 1000 * (self.width)/100
                                    }
                                    if((self.width / 100) > 4){
                                        risk_leverage = "high leverage ratios are very risky."
                                    }
                                })
                        
                        )
                }
            }
            VStack{
                HStack{
                    Text("\nRisk").font(.largeTitle)
                        Spacer()
                    Text("money available:$\(Int(ablemoney))").font(.largeTitle)
                }
                    chart(data: datalist)
                }
            Text(risk_leverage)
                .font(.largeTitle)
        }
        .background(Color.red.opacity(riskdepth))
    }
}

struct howsolve : View{
    var body: some View{
        ZStack{
            Color.gray
            //Color("intropage")
            VStack{
                Text("how to solve it?").font(.largeTitle)
                Image("howsolve")
            }
        }
    }
}
