//
//  File.swift
//  wwdc_submission
//
//  Created by mystic on 2022/04/17.
//

import SwiftUI

struct startintro:View{
    var body: some View{
        ZStack {
            Color.ivory
            //Color("intropage")
            VStack{
            Spacer()
             Text("Stock with Swift playgrounds")
                    .font(.largeTitle)
            Spacer()
            Spacer()
            Spacer()
            }
            .background(
                Image("readbookcat")
        )
        }
    }
}

struct describe_stock : View{
    var body: some View{
        ZStack {
            Color.ivory
            VStack{
                Text("usually, most people think stock market is beautiful and stable along with studying financial statements, companies and some theories.")
                    .font(.largeTitle)
                Spacer()
            }.padding()
            .background(
            Image("buy&sell")
            )
        }
    }
}

struct intro_danger : View{
    var body: some View{
        ZStack{
            Color("dangercolor")
            VStack{
                Text("however, stock market is dangerous for some people")
                    .font(.largeTitle)
                Spacer()
            }.padding()
            .background(
            Image("dangerous")
            )
        }
    }
}
