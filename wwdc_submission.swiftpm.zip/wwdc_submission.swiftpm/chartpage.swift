//
//  File.swift
//  wwdc_submission
//
//  Created by mystic on 2022/04/17.
//

import SwiftUI

struct start_stockmarket : View{
    var body: some View{
        ZStack {
            Color.gray
            VStack{
                Text("Learn about stock market")
                    .font(.largeTitle)
                Image("learn")
            }
        }
    }
}


struct chart: View {
    var data : [CGFloat]
    @State var currentprice = ""
    
    @State var offset : CGSize = .zero
    
    @State var showPlot = false
    
    @State var translation : CGFloat = 0
    
    var body: some View {
        GeometryReader { proxy in
            let height = proxy.size.height
            let width = (proxy.size.width) / CGFloat(data.count-1)
            let maxPoint = (data.max() ?? 0) + 100
            
            let points = data.enumerated().compactMap { item -> CGPoint in
                let progress = item.element / maxPoint
                
                let pathHeight = progress * height
                
                let pathWidth = width * CGFloat(item.offset)
                return CGPoint(x: pathWidth, y:-pathHeight + height)
            }
            ZStack {
                
                Path{ path in
                    path.move(to: CGPoint(x: 0, y: 0))
                    
                    path.addLines(points)
                }
                .strokedPath(StrokeStyle(lineWidth: 1.5, lineCap: .round, lineJoin: .round))
                .fill(
                    LinearGradient(colors: [.red,.blue], startPoint: .leading, endPoint: .trailing)
                )
                LinearGradient(colors: [.pink.opacity(0.3),.purple.opacity(0.2),.blue.opacity(0.1)], startPoint: .top, endPoint: .bottom).clipShape(
                    Path{ path in
                        path.move(to: CGPoint(x: 0, y: 0))
                        
                        path.addLines(points)
                        
                        path.addLine(to: CGPoint(x: proxy.size.width, y: height))
                        
                        path.addLine(to: CGPoint(x: 0, y: height))
                    }
                )
            }
            .overlay (
                VStack(spacing:0){
                    Text(currentprice)
                        .font(.caption.bold())
                        .foregroundColor(.white)
                        .padding(.vertical,6)
                        .padding(.horizontal,10)
                        .background(.black,in:Capsule())
                    
                    Rectangle()
                        .fill(Color.black)
                        .frame(width: 1, height: 40)
                        .padding(.top)
                    Circle()
                        .fill(Color.black)
                        .frame(width: 22, height: 22)
                        .overlay(
                            Circle()
                                .fill(.white)
                                .frame(width:10,height:10)
                        )
                    
                    Rectangle()
                        .fill(Color.black)
                        .frame(width: 1, height: 50)
                
                }
                    .frame(width: 80, height: 170)
                    .offset(y:70)
                    .offset(offset)
                    .opacity(showPlot ? 1 : 0),
                    alignment: .bottomLeading
            ).contentShape(Rectangle())
                .gesture(DragGesture().onChanged({ value in
                    withAnimation {
                        showPlot = true
                    }
                    let translation = value.location.x - 40
                    
                    let index = max(min(Int((translation/width).rounded() + 1), data.count-1), 0)
                    
                    currentprice = "$ \(data[index])"
                    self.translation = translation
                    
                    offset = CGSize(width: points[index].x - 40, height: points[index].y - height)
                    
                }).onEnded({ value in
                    withAnimation {
                        showPlot = false
                    }
                }))
        }
    }
}

struct buy_sell : View{
    @State var accountbalance : Int = 1000
    @State var holdings : Int = 0
    @State var buyselldatalist : [CGFloat] = [0.1,0.2]
    var body : some View{
        GeometryReader{ geometry in
            ZStack {
                Color.white
                VStack {
                    Text("stock market moves on weekdays and chart are created as a result. People buy and sell stocks within their economic assets.as a result, their assets either increase or decrease. it doesn't look bad yet.\n")
                        .font(.largeTitle)
                        .padding()
                    HStack{
                        Text("account:$\(accountbalance)")
                            .font(.largeTitle)
                        Spacer()
                        Text("stock shares:\(holdings)")
                            .font(.largeTitle)
                    }
                    HStack{
                        Spacer()
                        Button {
                            if(accountbalance >= 100){
                                accountbalance = accountbalance - 100
                                holdings = holdings + 1
                            }
                        } label: {
                            Text("Buy")
                                .font(.largeTitle)
                                .foregroundColor(.white)
                                .padding()
                                .padding(.horizontal)
                                .background(Color.green)
                                .cornerRadius(10)
                                
                        }
                        Button {
                            let randomsell = Int.random(in: 0...220)
                            if(holdings>0){
                                    accountbalance = accountbalance + randomsell
                                    holdings = holdings - 1
                                self.buyselldatalist.append(CGFloat(randomsell-100))
                            }
                        } label: {
                            Text("Sell")
                                .font(.largeTitle)
                                .foregroundColor(.white)
                                .padding()
                                .padding(.horizontal)
                                .background(Color.red)
                                .cornerRadius(10)
                        }
                    }
                    VStack{
                        Text("profit").font(.largeTitle).fontWeight(.bold)
                        chart(data: buyselldatalist)
                        Spacer().frame(width:0,height: geometry.size.height/4)
                    }

                }
            }
        }
    }
}

