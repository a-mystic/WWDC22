//
//  File.swift
//  wwdc_submission
//
//  Created by mystic on 2022/04/17.
//

import SwiftUI

func linear_regression(inputdata:[Double]) -> Float{ //torch model parameters weights
    let W = [[1.9969e+26],
             [2.0000e+26],
             [2.0030e+26]]
    let b = [3.0120e+23]
    var sum : Double = 0
    for k in 0..<3{
        var small_sum : Double = 0
        for i in 0..<3{
               small_sum = small_sum + inputdata[k]*W[i][0]
        }
        sum = sum + small_sum
    }
    
    return Float((sum)/(pow(10, 27)) + b[0]/pow(10,24))
}

struct intro_quant : View{
    var body: some View{
        ZStack {
            Color.cream
            VStack(alignment:.leading){
                Text("one solution to managing leverage risk is quantitative trading that is a math.")
                    .font(.largeTitle)
             Text("most individual investors who use leverage prefer chart patterns. It is a set of numbers and can be expressed in a mathematical way.also, it can be used for stock trading with ai.\n")
                    .font(.largeTitle)
                    HStack{
                        Image("quantchart")
                        Image("ai")
                    }
                Text("\nyou can create your own strategy with this.")
                    .font(.largeTitle)
                Text("linear regression is one of the most basic theory of ai that is a prediction.")
                    .font(.largeTitle)
                Spacer()
            }
            .padding()
        }
    }
}

struct learn_linear_regression : View{
    @State var yvalue = ""
    var body: some View{
        GeometryReader{ geometry in
            ZStack{
                Color.white
            VStack(alignment:.leading){
                Text("for instance, if you study 1hour get 2points and study 2hour get 4points. you will prediction about the relationship between time and score.\nthen you can imagine the equation y = 2x and draw a graph.")
                    .font(.largeTitle)
                    .padding()
                TextField("enter y when x=4", text: $yvalue).font(.largeTitle).textFieldStyle(.roundedBorder)
                
                    chart(data: [0,100,200,300,400,500,600,700,800,900,1000])
                
                if(yvalue == "8"){
                    Text("it is linear regression. If you learn quantitative trading methods such as linear regression, you will be able to apply them to stock market.")
                        .font(.largeTitle)
                }
                Spacer().frame(width:0,height: geometry.size.height/6)
            }
        }
        }
        
}
}

struct experience_quant : View{
    @State var input_data = ""
    @State var result = ""
    @State var inputlist = [Double]()
    var body: some View{
        ZStack{
            Color.cream
            VStack{
                Text("applying linear regression to the stock market")
                    .font(.largeTitle)
                    .padding()
                TextField("input 3 days stock price. ex)100,200,300", text: $input_data)
                    .autocapitalization(.none)
                .textFieldStyle(.roundedBorder)
                .font(.largeTitle)
                Button {
                    if(input_data.contains(",") && !input_data.contains(")") && !input_data.contains("(")){
                        inputlist = input_data.components(separatedBy: ",").map({ (value : String) -> Double in return Double(value)!})

                        if(inputlist.count == 3){
                            result = "next day's expected stock price is $"+String(linear_regression(inputdata: inputlist))
                        }
                    }
                    
                } label: {
                    Text("prediction")
                        .padding()
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .background(Color.black)
                        .cornerRadius(10)
                }
                Image("prediction")
                Text(result).font(.largeTitle)
                Spacer()
                Text("(this result is not exact prediction. this is example about education. don't use this experience to real stock trading.)")

            }
        }
    }
}

struct learnmore : View{
    var body: some View{
        ZStack{
            Color.ivory
            VStack(alignment:.leading){
                Text("you have seen that math can be used in stock trading with linear regression.\nif you want to get better results, you can develop your own quantitative trading strategies.\n")
                    .font(.largeTitle)
                Text("good things to learn more\n-deep learning\n-economic and financial theory\n-mathmetics")
                    .font(.largeTitle)
                Image("learnmore")
            }
        }
        
    }
}

