import SwiftUI

struct ContentView: View {
    var pagelist : [Any] = [startintro(),describe_stock(),intro_danger(),start_stockmarket(),buy_sell(),leverage_page(),howsolve(),intro_quant(),learn_linear_regression(),experience_quant(),learnmore(),endpage()]
    @State var currentpageindex : Int = 0
    
    var body: some View {
        let leftbutton = Button {
            if(currentpageindex>0){
                withAnimation {
                    currentpageindex = currentpageindex - 1
                }
            }
        } label: {
            Image(systemName: "chevron.left")
                .font(.system(size: 30))
                .frame(width:30,height: 30)
        }
        
        let rightbutton = Button {
            if(currentpageindex<pagelist.count - 1){
                withAnimation {
                    currentpageindex = currentpageindex + 1
                }
            }
        } label: {
            Image(systemName: "chevron.right")
                .font(.system(size: 30))
                .frame(width:30,height: 30)
        }
        
        
        HStack{
            if(currentpageindex == 0){
                startintro()
                rightbutton
            }
            else if(currentpageindex == 1){
                leftbutton
                describe_stock()
                rightbutton
            }
            else if(currentpageindex == 2){
                leftbutton
                intro_danger()
                rightbutton
            }
            else if(currentpageindex == 3){
                leftbutton
                start_stockmarket()
                rightbutton
            }
            else if(currentpageindex == 4){
                leftbutton
                buy_sell()
                rightbutton
            }
            else if(currentpageindex == 5){
                leftbutton
                leverage_page()
                rightbutton
            }
            else if(currentpageindex == 6){
                leftbutton
                howsolve()
                rightbutton
            }
            else if(currentpageindex == 7){
                leftbutton
                intro_quant()
                rightbutton
            }
            else if(currentpageindex == 8){
                leftbutton
                learn_linear_regression()
                rightbutton
            }
            else if (currentpageindex == 9){
                leftbutton
                experience_quant()
                rightbutton
            }
            else if (currentpageindex == 10){
                leftbutton
                learnmore()
                rightbutton
            }
            else if(currentpageindex == 11){
                leftbutton
                endpage()
            }
        }
    }
}

struct endpage : View{
    var body: some View{
        ZStack(alignment:.center) {
            Color.black
            Text("The End")
                .font(.largeTitle)
                .foregroundColor(.white)
        }
    }
}
